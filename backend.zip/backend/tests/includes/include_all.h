#ifndef IncludeAll_H
#define IncludeAll_H

#include "customercare_all.cpp"
#include "reservation_all.cpp"
#include "inventory_all.cpp"
#include "ordering_all.cpp"
#include "cooking_all.cpp"
#include "management_all.cpp"

#endif
