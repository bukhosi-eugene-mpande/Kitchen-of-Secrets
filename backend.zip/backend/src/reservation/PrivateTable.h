#ifndef PrivateTable_H
#define PrivateTable_H

#include "Table.h"

class PrivateTable : public Table {
    public:
        PrivateTable();
        ~PrivateTable();
};

#endif