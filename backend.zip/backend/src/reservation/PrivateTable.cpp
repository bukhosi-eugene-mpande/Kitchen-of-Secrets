#include "PrivateTable.h"

PrivateTable::PrivateTable() : Table("Private", 6) {

}

PrivateTable::~PrivateTable() {

}
