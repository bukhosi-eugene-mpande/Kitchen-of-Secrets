#ifndef GeneralTable_H
#define GeneralTable_H

#include <string>
#include <vector>
#include <memory>

#include "Table.h"

class GeneralTable : public Table{

    public:
        GeneralTable();
        ~GeneralTable();

};

#endif