#ifndef PrivateSection_H
#define PrivateSection_H

#include "Section.h"
#include "PrivateTable.h"

class PrivateSection : public Section{
    public: 
        PrivateSection();
        ~PrivateSection();
};

#endif
