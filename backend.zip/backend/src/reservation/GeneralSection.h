#ifndef GeneralSection_H
#define GeneralSection_H

#include "Section.h"
#include "GeneralTable.h"

class GeneralSection : public Section{
    public: 
        GeneralSection();
        ~GeneralSection();
};

#endif
