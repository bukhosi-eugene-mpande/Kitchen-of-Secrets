#include "GeneralTable.h"

GeneralTable::GeneralTable() : Table("General", 4) {

}

GeneralTable::~GeneralTable() {

}