# Name: Ayanda Juqu
# Student Number: 21589021

# My Responsibilities In The Project: 
My responsibilities for this project include the Ordering system and the backend as well
# System Name: 
Ordering
# What Is The [Put Your System Name Here] Systems's Purpose:

# What Are The [Put Your System Name Here] System's Components:

# What Design Patterns Does The [Put Your System Name Here] System Use:

# What Other Systems Does The [Put Your System Name Here] System Interact With:

# Diagrams

## UML Class Diagrams

## My research:
Order taking manually with a paper and pen is confusing and prone to error. Furthermore, a number of people must be involved in the order cycle. For this reason, restaurants today have embraced the technology that allows them to accept orders directly through their POS systems.

The likelihood of human error is decreased by a centralized restaurant ordering system. The entire menu and table numbers are available to the waitstaff via their screens. They can generate instant KOT without the risk of confusion or delays thanks to it.

Restaurant owners can monitor and reduce the average time between tables. Direct tablet ordering is common in many restaurants. The system immediately updates to reflect the orders placed via the tablets. Each order's table turnover time is significantly slashed.

One system contains information about all in-house orders, takeout orders, and delivery orders. Based on the various orders, restaurants can create offers. The restaurants can add various payment options as well as personalized discount coupons to takeaway and delivery orders.

## Other UML Diagrams (activity, state, etc.)
