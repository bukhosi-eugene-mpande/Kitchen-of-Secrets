// TODO: implement the class
#include "Waiter.h"

Waiter::Waiter(){
}

Waiter::~Waiter(){

}

void Waiter::takeOrder(){

}

void Waiter::serveOrder(){

}

double Waiter::billOrder(){
    return 0;
}

void Waiter::sendOrdersToKitchen(){

}

void Waiter::giveOrderToCustomer(){

}

std::shared_ptr<MenuItem> Waiter::createFoodItem(){
    return nullptr;
}

std::shared_ptr<MenuItem> Waiter::createDrinkItem(){
    return nullptr;
}

std::shared_ptr<Menu> Waiter::createMenu(){
    return nullptr;
}

std::shared_ptr<Order> Waiter::getCanceledOrderFromKitchen(){
   return nullptr;
}

std::shared_ptr<Order> Waiter::getOrderFromKitchen(){
    return nullptr;
}

void Waiter::buildOrder(){

}

int Waiter::getId(){
    return 0;
}



